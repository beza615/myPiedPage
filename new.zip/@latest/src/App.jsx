import React from 'react'
import Header from './component/Header/Header'
import Hearo from './component/Hearo/Hearo'
import About from './component/About/About'
import MyService from './component/MyService/MyService'
import Portfolio from './component/Portfolio/Portfolio'
import Contact from './component/Contact/Contact'
import Footer from './component/Footer/Footer'

function App() {
  return (
    <div>
      <Header/>
      <Hearo/>
      <About/>
      <MyService/>
      <Portfolio/>
      <Contact/>
      <Footer/>


    </div>
  ) 
}

export default App