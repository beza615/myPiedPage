import React from 'react'
import './Portfolio.css'
import PortfolioCard from '../PortfolioCard/PortfolioCard'
import image from '../../assets/image/puppy-lovers-page-design.jpg'


function Portfolio() {
  return (
    <div className="portfolio">
      <div className="portfolioTitle">
        <h1>My latest Work</h1>
      </div>

      <div className="portfolioComponent">
        <PortfolioCard Portfolioimage={image} portfolioheadline="puppy page" />
        <PortfolioCard Portfolioimage={image} portfolioheadline="puppy page" />
        <PortfolioCard Portfolioimage={image} portfolioheadline="puppy page" />
      </div>
    </div>
  );
}

export default Portfolio