import React from 'react'
import './Contact.css'

function Contact() {
  return (
    <div className="contact">
      <div className="contactTitle">
        <h1>Get in teuch</h1>
      </div>
      <div className="contactBody">
        <div className="contactLeft">
          <h1>Let's talk</h1>
          <p>
            if you have any client which you want full stack web developer you
            can get the following social media
          </p>

          <ul>
            <li>
              <span>Email:-</span>
              kirstibeza@gmail.com
            </li>

            <li>
              <span>Name:-</span>
              kirstibeza@gmail.com
            </li>

            <li>
              <span>Location:-</span>
              kirstibeza@gmail.com
            </li>
          </ul>
        </div>

        <div className="contactRight">
          <label htmlFor="">Your Name</label>
          <input type="text" placeholder="Enter Your Name" />
          <label htmlFor="">Your Email</label>
          <input type="text" placeholder="Your Email" />
          <label htmlFor="">Write Your message</label>
          <textarea type="text" placeholder="Enter Your message" />
        </div>
      </div>
      <div className="contactButton">
        <button>Submit Now</button>
      </div>
    </div>
  );
}

export default Contact