import React from 'react'
import './Footer.css'

function Footer() {
  return (
    <div className="footer">
      <hr />

      <div className="footerInfo">
        <p>2025 Beza Adefris,All rights</p>
        <ul>
          <li>Term of services</li>
          <li>Privacy Policy</li>
          <li>connect with me</li>
        </ul>
      </div>
    </div>
  );
}

export default Footer