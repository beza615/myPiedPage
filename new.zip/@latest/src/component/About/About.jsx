import React from "react";
import './About.css'
import AboutImage from '../../assets/image/photo.jpg'
function About() {
  return (
    <div className="about">
      <div className="aboutTitle">
        <h1>About me</h1>
      </div>

      <div className="aboutBody">
        <div className="aboutImage">
          <img src={AboutImage} alt="" />
        </div>

        <div className="aboutDescAndSkill">
          <div className="aboutDescription">
            <p>i'm Frontend react web developer</p>
            <p>And i'm Software Engineering Student</p>
          </div>

          <div className="aboutSkill">
            <ul>
              <li>
                HTML{" "}
                <span>
                  <hr />
                </span>
              </li>
              <li>
                CSS{" "}
                <span>
                  <hr />
                </span>
              </li>
              <li>
                JAVASCRIPT{" "}
                <span>
                  <hr />
                </span>
              </li>
              <li>
                REACT{" "}
                <span>
                  <hr />
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
