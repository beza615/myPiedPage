import React from 'react'
import './Hearo.css'
import {Link} from 'react-router-dom'
import Image from '../../assets/image/photo.jpg'
function Hearo() {
  return (
    <div className="portHearo">
      <div className="myimage">
        <img src={Image} alt="" />
      </div>

      <div className="hearoHeading">
        <h1>
          <span>I'm Beza Adefris </span> And also Frontend Web Developer
        </h1>
      </div>
      <div className="hearoPara">
        <p> I'm Software Engineering Student</p>
      </div>

      <div className="hearobuttom">
        <Link className="connect hearolink" to="">
          Connect With Me
        </Link>
        <Link className=" resum hearolink" to="">
          My Resume
        </Link>
      </div>
    </div>
  );
}

export default Hearo