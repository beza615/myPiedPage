import React,{useState} from 'react'
import './Header.css'
import logo from '../../assets/image/image.png'
import {Link} from 'react-router-dom'

function Header() {
const [navValue, setNavValue] = useState("Home")
console.log(navValue);

return (
  <div className="portdev">
    <div className="logo">
      <img src={logo} alt="" />
    </div>

    <nav>
      <ul>
        <li
          onClick={(e) => setNavValue("Home")}
          className={navValue === "Home" ? "underline" : " "}
        >
          <Link to="">Home</Link>
        </li>

        <li
          onClick={(e) => setNavValue("About")}
          className={navValue === "About" ? "underline" : " "}
        >
          <Link to="">About</Link>
        </li>

        <li
          onClick={(e) => setNavValue("Service")}
          className={navValue === "Service" ? "underline" : " "}
        >
          <Link to="">Service</Link>
        </li>

        <li
          onClick={(e) => setNavValue("Portfolio")}
          className={navValue === "Portfolio" ? "underline" : " "}
        >
          <Link to="">Portfolio</Link>
        </li>

        <li
          onClick={(e) => setNavValue("contact")}
          className={navValue === "contact" ? "underline" : " "}
        >
          <Link to="">contact</Link>
        </li>
      </ul>
    </nav>

    <div className="portbutton">
      <Link href="">connect with me</Link>
    </div>
  </div>
);
}

export default Header